# Lagrer passordet mitt vekke fra hovedkoden for å ungå å vise det med et uheld. Passordet og brukernavnet er fjernet for åpenbare grunner
password = "Passord"
username = "Brukernavn"
