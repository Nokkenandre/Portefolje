# Brunvoll Bridge design app
Dette er en app jeg lagde i forbindelse med uplasering hos Brunvoll A/S. Den lar brukeren designe hvordan Brucon-5 styresystemet på en båt skal se ut.

## Hvorfor python?
Jeg valgte python fordi det er det språket jeg er mest kjent med og fordi python har veldig lite innebygd UX så jeg tenkte det ville være en morsom utfordring å lære meg det som finnes.
